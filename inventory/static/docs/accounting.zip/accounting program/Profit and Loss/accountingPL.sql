drop database if exists accountingPLdb;
create database if not exists accountingPLdb;

use accountingPLdb;


create table locations(
	location_id int unsigned not null auto_increment primary key,
    location_name nvarchar(50) not null
    
);


create table invoices(

	invoice_id int unsigned not null auto_increment primary key,
    
    date_name nvarchar (50) not null,
    debit_amount decimal (50) not null,
    credit_amount decimal (50) not null,
    balance_amount decimal (50) not null,
    
    advertizing_amount decimal (50) not null,
    depreciation_amount decimal (50) not null,
    insurance_amount decimal (50) not null,
    rent_amount decimal (50) not null,
    repair_amount decimal (50) not null,
    training_amount decimal (50) not null,
    vehicleops_amount decimal (50) not null,
    wages_amount decimal (50) not null,
    workerscomp_amount decimal (50) not null,
    totalrevenue_amount decimal (50) not null,
    profit_amount decimal (50) not null,
    
    employee_name nvarchar(100) not null,
    customer_name nvarchar(100) not null,
    location_id int unsigned,
   /* customer_phone nvarchar(10) not null, */
    /*customer_email nvarchar(100) not null,*/
    account_receivable decimal(18, 2),
    account_payable decimal(18, 2),
    created_date datetime default current_timestamp
    /*foreign key (location_id) references locations(location_id)*/
);

create table user(
	user_id int unsigned auto_increment primary key,
    username nvarchar (50),
    password nvarchar(50)
    );


insert into locations (location_name) values ('columbus: 26 apple road'),
	('columbus: 34 summer street'), ('columbus: sawmill boulevard'), ('cleveland: 2016 main street'), ('cleveleand: 1245 roses park');