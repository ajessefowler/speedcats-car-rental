<?php
include "mysql-connect.php";

function getResult(mysqli $db, string $query) {
	// mysqli_query($db, 'some SQL query');
	$result = $db->query($query);

	if (!$result) {
		// mysqli_error($conn)
		echo "<p>$db->error</p>";
	}

	return $result;
}





function getInvoices(mysqli $db) {
	$query = 'select * from locations l
	join invoices s 
	on l.location_id = s.location_id
	ORDER by s.location_id'; 
	
	return getResult($db, $query);
}

function getLocations(mysqli $db) {
	$query = 'select * from locations';
	
	return getResult($db, $query);
}

/*function getInvoicesByLocations(mysqli $db)
{

	$query = "select * from invoices WHERE location_id = $id";
	return getResult($db, $query);
}*/



/**
 * this function will execute when form is submitted,
 * we want to pull data from $_POST array and either
 * INSERT or UPDATE the invoice table (based on if we have
 * a primary key)
 */
function handleSubmit(mysqli $db) {
	// var_dump($_POST);
	$id = $_POST['id'];
	$datename = $_POST['date-name'];
	$advertizingamount = $_POST['advertizing-amount'];
	$depreciationamount = $_POST['depreciation-amount'];

	$insuranceamount = $_POST['insurance-amount'];
	$rentamount = $_POST['rent-amount'];
	$repairamount = $_POST['repair-amount'];
	$trainingamount = $_POST['training-amount'];
	$vehicleopsamount = $_POST['vehicleops-amount'];
	$wagesamount = $_POST['wages-amount'];
	$workerscompamount = $_POST['workerscomp-amount'];
	$totalrevenueamount = $_POST['totalrevenue-amount'];

	if(!is_numeric($advertizingamount) || !is_numeric($depreciationamount) || !is_numeric($insuranceamount)
	|| !is_numeric($rentamount)|| !is_numeric($repairamount)|| !is_numeric($trainingamount)
	|| !is_numeric($vehicleopsamount)|| !is_numeric($wagesamount)|| !is_numeric($workerscompamount)
	){
		echo "values must be numeric";
		return;
	}
	//$balanceamount = $_POST['balance_amount'];
	
	
	$totalexpensesamount = $advertizingamount+ $depreciationamount + $insuranceamount+ $rentamount
	+ $repairamount + $trainingamount+ $vehicleopsamount + $wagesamount + $workerscompamount;

	$profitamount = $totalrevenueamount - $totalexpensesamount;
	$profitpercentage = ($profitamount/$totalrevenueamount) * 100;

	$location = $_POST['location'];

	/*$completed = isset($_POST['completed']) ? 1 : 0;
	$completed2 = isset($_POST['completed2']) ? 1 : 0;*/

	
	

	// basic form validation
	if (empty($datename) || empty($advertizingamount) || empty($depreciationamount)) {
		echo "<p>All fields are required</p>";
		return;
	}

	/*if (!is_numeric($accountpayable)) {
		echo "<p>accounts must be numeric</p>";
		return;
	}*/

	// build SQL query
	// if id is not an empty string and is numeric, we have a
	// primary key (UPDATE)
	if (!empty($id) && is_numeric($id)) {
		$query = "UPDATE invoices SET date_name = '$datename', 
			advertizing_amount = '$advertizingamount',  depreciation_amount = '$depreciationamount', 
			insurance_amount = '$insuranceamount',
			rent_amount = '$rentamount', repair_amount = '$repairamount', training_amount = '$trainingamount',
			vehicleops_amount = '$vehicleopsamount', wages_amount = '$wagesamount', workerscomp_amount = '$workerscompamount',
			totalrevenue_amount = '$totalrevenueamount', profit_amount = '$profitamount' WHERE invoice_id = $id";
	} else {
		// no primary key, create new record (INSERT)
		$query = "INSERT INTO invoices (date_name, advertizing_amount, depreciation_amount, insurance_amount, 
		rent_amount, repair_amount, training_amount, vehicleops_amount, wages_amount, 
		workerscomp_amount, totalrevenue_amount, profit_amount,
		location_id) 
		VALUES ('$datename','$advertizingamount', '$depreciationamount', '$insuranceamount', 
		'$rentamount', '$repairamount', '$trainingamount', 
		'$vehicleopsamount', '$wagesamount', '$workerscompamount', '$totalrevenueamount', '$profitamount',
		'$location')";
	}
	$result = $db->query($query);
 
	if ($result) {
		// success, do something
		header('Location: index.php');
	} else {
		// failure, do PLAN B
		echo "<p>Error: $db->error</p>";
	}
}

function deleteInvoice(mysqli $db, int $id) {
	$query = "DELETE FROM invoices WHERE invoice_id = $id";

	if (!$db->query($query)) {
		echo "Error: $db->error";
		return;
	}

	header('Location: index.php');
}