<?php
$locations = getLocations($conn);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	handleSubmit($conn);
}
?>
<br>
<a href="index.php">Go back<a>
<form action="" method="post">
	<fieldset>
		<legend>Accounting form</legend>
		<input type="hidden" name="id"
			value="<?=isset($invoice) ? $invoice->invoice_id : ""?>">

		<input placeholder="Enter Quarter" name="date-name" type="text" 
			value="<?=isset($invoice) ? $invoice->date_name : ""?>">

		<select name="location">
			<option value="">Choose Location</option>
			<?php if ($locations): ?>
				<?php foreach($locations as $row): ?>
					<option value="<?=$row['location_id']?>"
					<?=isset($invoice) && $invoice->location_id === $row['location_id'] ?
						'selected' : ''?>>
						<?=$row['location_name']?>
					</option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>

		<input placeholder="Advertizing Amount" name="advertizing-amount" type="text"
			value="<?=isset($invoice) ? $invoice->advertizing_amount : ""?>">
		
		<input placeholder="Depreciation Amount" name="depreciation-amount" type="text"
			value="<?=isset($invoice) ? $invoice->depreciation_amount : ""?>">

		
		<input placeholder="Insurance Amount" name="insurance-amount" type="text"
			value="<?=isset($invoice) ? $invoice->insurance_amount : ""?>">

		<input placeholder="Rent Amount" name="rent-amount" type="text"
			value="<?=isset($invoice) ? $invoice->rent_amount : ""?>">

		<input placeholder="Repair and Maintenance" name="repair-amount" type="text"
			value="<?=isset($invoice) ? $invoice->repair_amount : ""?>">

		<input placeholder="Training Amount" name="training-amount" type="text"
			value="<?=isset($invoice) ? $invoice->training_amount : ""?>">

		<input placeholder="Vehicle Operations Costs" name="vehicleops-amount" type="text"
			value="<?=isset($invoice) ? $invoice->vehicleops_amount : ""?>">

		<input placeholder="Wages and Salaries" name="wages-amount" type="text"
			value="<?=isset($invoice) ? $invoice->wages_amount : ""?>">

		<input placeholder="Workers Compensation" name="workerscomp-amount" type="text"
			value="<?=isset($invoice) ? $invoice->workerscomp_amount : ""?>">

		<input placeholder="Total Revenue" name="totalrevenue-amount" type="text"
			value="<?=isset($invoice) ? $invoice->totalrevenue_amount : ""?>">



		<button type="submit">Save</button>
	</fieldset>
</form>