<?php 
include "includes/header.php";
$invoices = getInvoices($conn);
?>
<h1 class="titre" align="center" >Profit and Loss</h1>
<p><a class="button2" href="add-invoice.php"> Add To Profit and Loss Ledger </a> <a href="search.php">| search</a> </p>


<?php if ($invoices): ?> 
<table>
	<tr>
	
	<th>Quarter</th>
	<th>Location</th>
	<th>Advertizing</th>
		<th>Depreciation</th>
		<th>Insurance</th>
		<th>Rent</th>
		<th>Repair</th>
		<th>Training</th>
		<th>Vehicles Operation Costs</th>
		<th>Wages</th>
		<th>Workers Compensation</th>
		<th>Total Revenue</th>
		<th>Profit</th>
		
		
		
		
		<th>Action</th>
	</tr>
	<?php foreach ($invoices as $row): ?>
	<tr>
	
		<td><?=$row['date_name']?></td>
		<td><?=$row['location_name']?></td>
		<td>$<?=$row['advertizing_amount']?></td>
		<td>$<?=$row['depreciation_amount']?></td>
		<td>$<?=$row['insurance_amount']?></td>
		<td>$<?=$row['rent_amount']?></td>
		<td>$<?=$row['repair_amount']?></td>
		<td>$<?=$row['training_amount']?></td>
		<td>$<?=$row['vehicleops_amount']?></td>
		<td>$<?=$row['wages_amount']?></td>
		<td>$<?=$row['workerscomp_amount']?></td>
		<td>$<?=$row['totalrevenue_amount']?></td>
		<td>$<?=$row['profit_amount']?></td>
		
		
		
		

		<td>
			<a class="button" href="edit-invoice.php?id=<?=$row['invoice_id']?>">Edit</a>&nbsp
			
			<a class="button4" href="delete-invoice.php?id=<?=$row['invoice_id']?>"
				onclick="return confirm('Are you sure?')">Delete</a>
		</td>
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>
<?php include "includes/footer.php" ?>