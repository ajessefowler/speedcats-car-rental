<?php
$locations = getLocations($conn);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	handleSubmit($conn);
}
?>
<br>
<a href="index.php">Go back<a>
<form action="" method="post">
	<fieldset>
		<legend>Accounting form</legend>
		<input type="hidden" name="id"
			value="<?=isset($invoice) ? $invoice->invoice_id : ""?>">

		<input placeholder="Account Name" name="account-name" type="text" 
			value="<?=isset($invoice) ? $invoice->account_name : ""?>">

		<select name="location">
			<option value="">Choose Location</option>
			<?php if ($locations): ?>
				<?php foreach($locations as $row): ?>
					<option value="<?=$row['location_id']?>"
					<?=isset($invoice) && $invoice->location_id === $row['location_id'] ?
						'selected' : ''?>>
						<?=$row['location_name']?>
					</option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
		
		<input placeholder="Account Number" name="account-number" type="text"
			value="<?=isset($invoice) ? $invoice->account_number : ""?>">

		
		<input placeholder="Invoice Number" name="invoice-number" type="text"
			value="<?=isset($invoice) ? $invoice->invoice_number : ""?>">

		<input placeholder="Invoice Amount" name="invoice-amount" type="text"
			value="<?=isset($invoice) ? $invoice->invoice_amount : ""?>">

		<input placeholder="Due Date" name="due-date" type="text"
			value="<?=isset($invoice) ? $invoice->due_date : ""?>">

		<input placeholder="Date Paid" name="date-paid" type="text"
			value="<?=isset($invoice) ? $invoice->date_paid : ""?>">

		<input placeholder="Days Overdue" name="days-overdue" type="text"
			value="<?=isset($invoice) ? $invoice->days_overdue : ""?>">



		<button type="submit">Save</button>
	</fieldset>
</form>