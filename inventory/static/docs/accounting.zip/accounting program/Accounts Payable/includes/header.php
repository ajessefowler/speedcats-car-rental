<?php 
include "./includes/functions.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Speedcats Car Rental</title>
	<style>
		html, body { font: 16px normal Arial, sans-serif; }
		table { border-collapse: collapse; }
		h1 { font: 1.5em normal Arial, sans-serif; }
		th, td { padding: 10px; border: 1px solid #888; }
		footer { margin-top: 1em; }
		input[type="text"], button, select { display: block; margin: 1em 0; }




		html, body { font: 16px normal Arial, sans-serif; }
		
		table { border-collapse: collapse; } 


	.titre{
		color: blue;
		/*color: #343434;*/
	text-shadow: 0 2px white, 0 5px #777;

	}


		.button {
    display: block;
    width: 115px;
    height: 30px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}

.button4 {
    display: block;
    width: 115px;
    height: 15px;
    background: red;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

.button3 {
    display: block;
    width: 115px;
    height: 15px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

.button2 {
    display: block;
    width: 200px;
    height: 30px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}

.button1 {
    display: block;
    width: 85px;
    height: 20px;
    background: #4E9CAF;
    padding: 5px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

		table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

#mydiv{
            text-align:center;display:block;
        }


tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
		h1 { font: 1.5em normal Arial, sans-serif; }
		th, td { padding: 5px; border: 1px solid #888; }
		footer { margin-top: 1em; }
		input[type="text"], input[type="password"], button, select { display: block; margin: 1em 0; }
	</style>
	
</head>
<body>