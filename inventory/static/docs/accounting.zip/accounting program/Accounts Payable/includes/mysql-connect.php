<?php

// $conn = mysqli_connect('localhost', 'root', '', 'gamedb');
$conn = new mysqli('localhost', 'root', '', 'accountingARdb');