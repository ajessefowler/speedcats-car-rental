<footer>Copyright &copy; <?=date('Y')?> Speedcats Car Rental</footer>
</body>
</html>