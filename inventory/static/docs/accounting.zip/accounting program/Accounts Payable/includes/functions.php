<?php
include "mysql-connect.php";

function getResult(mysqli $db, string $query) {
	
	$result = $db->query($query);

	if (!$result) {
		
		echo "<p>$db->error</p>";
	}

	return $result;
}





function getInvoices(mysqli $db) {
	$query = 'select * from locations l
	join invoices s 
	on l.location_id = s.location_id
	ORDER by s.location_id'; 
	
	return getResult($db, $query);
}

function getLocations(mysqli $db) {
	$query = 'select * from locations';
	
	return getResult($db, $query);
}


function handleSubmit(mysqli $db) {
	
	$id = $_POST['id'];
	$accountname = $_POST['account-name'];
	$accountnumber = $_POST['account-number'];

	$invoicenumber = $_POST['invoice-number'];
	$invoiceamount = $_POST['invoice-amount'];
	$duedate = $_POST['due-date'];
	$datepaid = $_POST['date-paid'];
	$daysoverdue = $_POST['days-overdue'];



	$location = $_POST['location'];

	if (empty($accountname) || empty($accountnumber) || empty($invoicenumber)) {
		echo "<p>All fields are required</p>";
		return;
	}

	if (!empty($id) && is_numeric($id)) {
		$query = "UPDATE invoices SET account_name = '$accountname', 
			account_number = '$accountnumber',  invoice_number = '$invoicenumber', invoice_amount = '$invoiceamount',
			due_date = '$duedate', date_paid = '$datepaid', days_overdue = '$daysoverdue'
			WHERE invoice_id = $id";
	} else {
	
		$query = "INSERT INTO invoices (account_name, account_number, invoice_number, 
		invoice_amount, due_date, date_paid, days_overdue, 
		location_id) 
		VALUES ('$accountname','$accountnumber', '$invoicenumber', '$invoiceamount', '$duedate', '$datepaid', '$daysoverdue', '$location')";
	}
	$result = $db->query($query);
 
	if ($result) {
		
		header('Location: index.php');
	} else {

		echo "<p>Error: $db->error</p>";
	}
}

function deleteInvoice(mysqli $db, int $id) {
	$query = "DELETE FROM invoices WHERE invoice_id = $id";

	if (!$db->query($query)) {
		echo "Error: $db->error";
		return;
	}

	header('Location: index.php');
}