<?php if(!isset($_SESSION)){session_start();}?>
<?php print_r($_SESSION); 

?>
<?php 
include "includes/header.php";
echo $locationname = $_SESSION['location_name'];

$query = "select * from invoices WHERE location_name = $locationname";
	$result = $conn->query($query);

	if ($result->num_rows > 0) {
		echo "<table><tr><th>ID</th><th>Name</th></tr>";
		
		while($row = $result->fetch_assoc()) {
			echo "<tr><td>".$row["id"]."</td><td>".$row["firstname"]." ".$row["lastname"]."</td></tr>";
		}
		echo "</table>";
	} else {
		echo "0 results";
	}