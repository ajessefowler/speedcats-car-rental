<?php
include "includes/functions.php";

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
	deleteInvoice($conn, $_GET['id']);
}

?>
<a hef="index.php">Go back</a>