<?php if(!isset($_SESSION)){session_start();}?>
<?php print_r($_SESSION); ?>
<?php
include "./includes/header.php";

if (isset($_POST['locationname']))
{
	$locationname= $_POST['locationname'];
	$_SESSION['location_name'] = $locationname;
	echo $locationname;
}
?>





<?php



   
?>
<a href="index.php">Go back<a>
<form action="result_by_location.php" method="post">
	<fieldset>
		<legend>Accounting form</legend>
		

		

		<input placeholder="Location Name" name="locationname" type="text">
			
		
		<button type="submit"> Submit </button>
		
	</fieldset>

</form>



    <?php include "./includes/footer.php" ?>