<?php 
include "includes/header.php";
$invoices = getInvoices($conn);
?>
<h1 class="titre" align="center" >General Ledger</h1>
<p><a class="button2" href="add-invoice.php"> Add To General Ledger </a> <a href="search.php">| search</a> </p>


<?php if ($invoices): ?> 
<table>
	<tr>
	<th> Transaction Number</th>
	<th>Date</th>
		<th>Debit</th>
		<th>Credit</th>
		<th>Location Name</th>
		
		<th>Balance</th>
		
		
		<th>Action</th>
	</tr>
	<?php foreach ($invoices as $row): ?>
	<tr>
		<td> <?=$row['invoice_id']?></td>
		<td><?=$row['date_name']?></td>
		<td>$<?=$row['debit_amount']?></td>
		<td>$<?=$row['credit_amount']?></td>
		<td><?=$row['location_name']?></td>
		<td>$<?=$row['balance_amount']?></td>
		
		
		
		

		<td>
			<a class="button" href="edit-invoice.php?id=<?=$row['invoice_id']?>">Edit</a>&nbsp
			
			<a class="button4" href="delete-invoice.php?id=<?=$row['invoice_id']?>"
				onclick="return confirm('Are you sure?')">Delete</a>
		</td>
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>
<?php include "includes/footer.php" ?>