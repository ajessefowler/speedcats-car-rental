<?php include "./includes/header.php" ?>
<?php
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$query = "SELECT * FROM invoices WHERE invoice_id = $id";
	$result = getResult($conn, $query);
	if ($result && $result->num_rows === 1) {
		$invoice = $result->fetch_object();
	}
}
?>
<?php include "./includes/invoice-form.php" ?>
<?php include "./includes/footer.php" ?>