<?php
$locations = getLocations($conn);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	handleSubmit($conn);
}
?>
<br>
<a href="index.php">Go back<a>
<form action="" method="post">
	<fieldset>
		<legend>Accounting form</legend>
		<input type="hidden" name="id"
			value="<?=isset($invoice) ? $invoice->invoice_id : ""?>">

		<input placeholder="Month/Day/Year" name="date_name" type="date" 
			value="<?=isset($invoice) ? $invoice->date_name : ""?>">

		<select name="location">
			<option value="">Choose Location</option>
			<?php if ($locations): ?>
				<?php foreach($locations as $row): ?>
					<option value="<?=$row['location_id']?>"
					<?=isset($invoice) && $invoice->location_id === $row['location_id'] ?
						'selected' : ''?>>
						<?=$row['location_name']?>
					</option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
		
		<input placeholder="Debit Amount" name="debit_amount" type="text"
			value="<?=isset($invoice) ? $invoice->debit_amount : ""?>">

		
		<input placeholder="Credit Amount" name="credit_amount" type="text"
			value="<?=isset($invoice) ? $invoice->credit_amount : ""?>">

		<input placeholder="Balance Amount" name="balance_amount" type="text"
			value="<?=isset($invoice) ? $invoice->balance_amount : ""?>">



		<button type="submit">Save</button>
	</fieldset>
</form>