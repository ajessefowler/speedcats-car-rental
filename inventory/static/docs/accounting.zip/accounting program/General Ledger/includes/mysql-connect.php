<?php


$conn = new mysqli('localhost', 'root', '', 'accountingGLdb');