<?php 
include "includes/header.php";
$invoices = getInvoices($conn);
?>
<h1 class="titre" align="center" >Accounts Receivable</h1>
<p><a class="button2" href="add-invoice.php"> Add To Accounts Receivable </a> <a href="search.php">| search</a> </p>


<?php if ($invoices): ?> 
<table>
	<tr>
	<th> Account Name</th>
	<th>Location</th>
	<th>Account Number</th>
		<th>Invoice Number</th>
		<th>Invoice Amount</th>
		<th>Due Date</th>
		
		<th>Date Paid</th>
		<th>Days Overdue</th>
		
		
		<th>Action</th>
	</tr>
	<?php foreach ($invoices as $row): ?>
	<tr>
		<td> <?=$row['account_name']?></td>
		<td><?=$row['location_name']?></td>
		<td><?=$row['account_number']?></td>
		<td><?=$row['invoice_number']?></td>
		<td>$<?=$row['invoice_amount']?></td>
		
		<td><?=$row['due_date']?></td>
		<td><?=$row['date_paid']?></td>
		<td><?=$row['days_overdue']?></td>
		
		
		
		

		<td>
			<a class="button" href="edit-invoice.php?id=<?=$row['invoice_id']?>">Edit</a>&nbsp
			
			<a class="button4" href="delete-invoice.php?id=<?=$row['invoice_id']?>"
				onclick="return confirm('Are you sure?')">Delete</a>
		</td>
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>
<?php include "includes/footer.php" ?>