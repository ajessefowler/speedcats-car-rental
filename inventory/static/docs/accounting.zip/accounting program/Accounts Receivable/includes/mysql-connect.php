<?php


$conn = new mysqli('localhost', 'root', '', 'accountingARdb');