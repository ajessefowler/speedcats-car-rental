
<br>
<h1 class="titre" align="center" ><b>Cost Summary</b></h1>
<br>
<?php
$costs=array
(
array("<b>Backbone</b>","","", "", ""),
array("Cisco 4301",1200,4.0, 4000, ""),
array("Serial Cabling (Fiber Optic)",150,4500,675000, "8 offices"),
array("Backup Power Supply",200,4.0, 600, "small generator"),
array("Cloud Computing",1000,1.0, 1000, ""),
array("Firewall",500,1.0, 500, ""),

array("<b>Branch Offices</b>","","", "", ""),
array("Cisco 1941",550,8.0, 4400, "one per office"),
array("Switch Model 2600",300,8.0, 2400, "one per office"),
array("Destop Computer",500,64.0, 32000, "8 per office"),
array("WAP",100,8.0, 800, "one per office"),
array("Printer",500,8.0, 4000, "one per office"),
array("Tablet to test WAP",150,8.0, 1200, "one per office"),
array("Office Wallplates",3,64, 192, "8 feet per office"),
array("Backup Power Supply",100,8.0, 800, "one per office"),
array("Alarm System",300,8.0, 2400, "one per office"),
array("Cameras",150,32.0, 4800, "4 per office"),
array("Keypad System",200,8.0, 1600, "one per office"),
array("Fire Sprinkler System",5000,8.0, 40000, "one per office"),
array("Power Strip",200,8.0, 1600, "one per office"),
array("Rack",150,8.0, 1200, "one per office"),

array("<b>Installation</b>","","", "", ""),
array("Electricians",60,1000, 60000, ""),
array("Construction",30,200.0, 6000, ""),
array("IT Stuff",40,1000, 40000, ""),

array("<b>Training</b>","","", "", ""),
array("IT Stuff",2000,1.0, 2000, ""),

array("<b>Support</b>","","", "", ""),
array("One year (by the hour)",40,100.0, 4000, ""),

array("<b>Total</b>","","", "1,691,492", ""),

);

 if ($costs): ?> 
<table>
	<tr>
	<th> Item</th>
	<th>Item Cost</th>
	<th>Quantity</th>
		<th>Total </th>
		<th>Notes</th>
		
	</tr>
	<?php foreach ($costs as $row): ?>
	<tr>
		<td> <?=$row[0]?></td>
		<td>$<?=$row[1]?></td>
		<td><?=$row[2]?></td>
        <td>$<?=$row[3]?></td>
        <td><?=$row[4]?></td>
		
		
		
		
		

		
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>
<style>
		html, body { font: 16px normal Arial, sans-serif; }
		table { border-collapse: collapse; }
		h1 { font: 1.5em normal Arial, sans-serif; }
		th, td { padding: 10px; border: 1px solid #888; }
		footer { margin-top: 1em; }
		input[type="text"], button, select { display: block; margin: 1em 0; }




		html, body { font: 16px normal Arial, sans-serif; }
		
		table { border-collapse: collapse; } 


	.titre{
		color: blue;
		/*color: #343434;*/
	text-shadow: 0 2px white, 0 5px #777;

	}


		.button {
    display: block;
    width: 115px;
    height: 30px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}

.button4 {
    display: block;
    width: 115px;
    height: 15px;
    background: red;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

.button3 {
    display: block;
    width: 115px;
    height: 15px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

.button2 {
    display: block;
    width: 200px;
    height: 30px;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
}

.button1 {
    display: block;
    width: 85px;
    height: 20px;
    background: #4E9CAF;
    padding: 5px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    
}

		table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

#mydiv{
            text-align:center;display:block;
        }


tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #4CAF50;
    color: white;
}
		h1 { font: 1.5em normal Arial, sans-serif; }
		th, td { padding: 15px; border: 1px solid #888; }
		footer { margin-top: 1em; }
		input[type="text"], input[type="password"], button, select { display: block; margin: 1em 0; }
	</style>
