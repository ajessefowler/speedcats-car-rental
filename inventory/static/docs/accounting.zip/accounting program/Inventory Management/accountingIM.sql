drop database if exists accountingIMdb;
create database if not exists accountingIMdb;

use accountingIMdb;


create table locations(
	location_id int unsigned not null auto_increment primary key,
    location_name nvarchar(50) not null
    
);


create table invoices(
	invoice_id int unsigned not null auto_increment primary key,
    employee_name nvarchar(100) not null,
    customer_name nvarchar(100) not null,
    location_id int unsigned,
   /* customer_phone nvarchar(10) not null, */
    /*customer_email nvarchar(100) not null,*/
    account_receivable decimal(18, 2),
    account_payable decimal(18, 2),
    created_date datetime default current_timestamp
    /*foreign key (location_id) references locations(location_id)*/
);

create table user(
	user_id int unsigned auto_increment primary key,
    username nvarchar (50),
    password nvarchar(50)
    );


insert into locations (location_name) values ('columbus: 26 apple road'),
	('columbus: 34 summer street'), ('columbus: sawmill boulevard'), ('cleveland: 2016 main street'), ('cleveleand: 1245 roses park');