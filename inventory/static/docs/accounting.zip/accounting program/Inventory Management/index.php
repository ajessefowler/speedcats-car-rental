<?php 
include "includes/header.php";
$invoices = getInvoices($conn);
?>
<h1  class="titre" align="center">Inventory Control</h1>
<p><a class="button2" href="add-invoice.php">Manage Available Cars </a> <a href="search.php">| search</a> </p>


<?php if ($invoices): ?> 
<table>
	<tr>
	<th>Car VIN code</th>
		<th>Care Make</th>
		<th>Car Model</th>
		<th>Location Name</th>
		
		<th>Odometer</th>
		
		
		<th>Action</th>
	</tr>
	<?php foreach ($invoices as $row): ?>
	<tr>
		<td>VIN0 <?=$row['invoice_id']?></td>
		<td><?=$row['employee_name']?></td>
		<td><?=$row['customer_name']?></td>
		<td><?=$row['location_name']?></td>
		<td><?=$row['account_receivable']?> mi</td>
		
		
		
		

		<td>
			<a class="button" href="edit-invoice.php?id=<?=$row['invoice_id']?>">Edit</a><br>
			
			<a class="button4" href="delete-invoice.php?id=<?=$row['invoice_id']?>"
				onclick="return confirm('Are you sure?')">Delete</a>
				
		</td>
	</tr>
	<?php endforeach; ?>
</table>
<?php endif; ?>
<?php include "includes/footer.php" ?>