<?php
$locations = getLocations($conn);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	handleSubmit($conn);
}
?>
<a href="index.php">Go back<a>
<form action="" method="post">
	<fieldset>
		<legend>Accounting form</legend>
		<input type="hidden" name="id"
			value="<?=isset($invoice) ? $invoice->invoice_id : ""?>">

		<input placeholder="Car Make" name="employee_name" type="text"
			value="<?=isset($invoice) ? $invoice->employee_name : ""?>">

		<select name="location">
			<option value="">Choose Location</option>
			<?php if ($locations): ?>
				<?php foreach($locations as $row): ?>
					<option value="<?=$row['location_id']?>"
					<?=isset($invoice) && $invoice->location_id === $row['location_id'] ?
						'selected' : ''?>>
						<?=$row['location_name']?>
					</option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
		
		<input placeholder="Car Model" name="customer_name" type="text"
			value="<?=isset($invoice) ? $invoice->customer_name : ""?>">

		
		<input placeholder="Account Payable" name="account_payable" type="text"
			value="<?=isset($invoice) ? $invoice->account_payable : ""?>">

		<input placeholder="Odometer in miles" name="account_receivable" type="text"
			value="<?=isset($invoice) ? $invoice->account_receivable : ""?>">



		<button type="submit">Save</button>
	</fieldset>
</form>