<?php
include "mysql-connect.php";

function getResult(mysqli $db, string $query) {
	
	$result = $db->query($query);

	if (!$result) {
		
		echo "<p>$db->error</p>";
	}

	return $result;
}





function getInvoices(mysqli $db) {
	$query = 'select * from locations l
	join invoices s 
	on l.location_id = s.location_id
	ORDER by s.location_id'; 
	
	return getResult($db, $query);
}

function getLocations(mysqli $db) {
	$query = 'select * from locations';
	
	return getResult($db, $query);
}

 */
function handleSubmit(mysqli $db) {
	
	$id = $_POST['id'];
	$invoicename = $_POST['employee_name'];
	$customername = $_POST['customer_name'];

	$accountpayable = $_POST['account_payable'];
	$accountreceivable = $_POST['account_receivable'];

	$location = $_POST['location'];

	
	if (empty($invoicename) || empty($customername)) {
		echo "<p>All fields are required</p>";
		return;
	}


	if (!empty($id) && is_numeric($id)) {
		$query = "UPDATE invoices SET employee_name = '$invoicename', 
			customer_name = '$customername',  account_payable = '$accountpayable', account_receivable = '$accountreceivable'
			WHERE invoice_id = $id";
	} else {
		
		$query = "INSERT INTO invoices (employee_name, customer_name, account_receivable, account_payable, location_id) 
		VALUES ('$invoicename','$customername', '$accountreceivable', '$accountpayable', '$location')";
	}
	$result = $db->query($query);
 
	if ($result) {
		
		header('Location: index.php');
	} else {
		
		echo "<p>Error: $db->error</p>";
	}
}

function deleteInvoice(mysqli $db, int $id) {
	$query = "DELETE FROM invoices WHERE invoice_id = $id";

	if (!$db->query($query)) {
		echo "Error: $db->error";
		return;
	}

	header('Location: index.php');
}